# RIVET Pro Workflow Architecture

## Main Flow

```mermaid
flowchart TD
    subgraph TELEGRAM["📱 Telegram Input"]
        A[Photo Received] --> B{Has Photo?}
        B -->|No| A1[Request Photo]
        B -->|Yes| C[Get File from Telegram]
    end

    subgraph OCR["🔍 OCR Processing"]
        C --> D[Download Photo]
        D --> E[Gemini Vision OCR]
        E --> F[Parse Response]
        F --> G{Confidence >= 70%?}
        G -->|No| H[Ask User to Clarify]
    end

    subgraph CMMS["📋 Atlas CMMS"]
        G -->|Yes| I[Search Existing Assets]
        I --> J{Asset Exists?}
        J -->|Yes| K[Update Asset Record]
        J -->|No| L[Create New Asset]
        K --> M[Continue to Search]
        L --> M
    end

    subgraph SEARCH["🔎 Manual Search"]
        M --> N[Quick Search - Tavily]
        N --> O{PDF Found?}
        O -->|Yes| P[Send PDF Link ✅]
        O -->|No| Q[Deep Search - Manufacturer Site]
        Q --> R{Found After Deep Search?}
        R -->|Yes| S[Send Deep Result ✅]
        R -->|No| T[Send Not Found ⚠️]
    end

    style TELEGRAM fill:#E3F2FD,stroke:#1976D2
    style OCR fill:#FFF3E0,stroke:#F57C00
    style CMMS fill:#E8F5E9,stroke:#388E3C
    style SEARCH fill:#FCE4EC,stroke:#C2185B
```

## Detailed Node Flow

```mermaid
flowchart LR
    subgraph INPUT
        T1[Telegram Trigger]
    end
    
    subgraph VALIDATION
        T1 --> IF1{Photo?}
        IF1 -->|No| MSG1[Request Photo]
        IF1 -->|Yes| GET[Get File]
    end
    
    subgraph PROCESSING
        GET --> DL[Download]
        DL --> OCR[Gemini OCR]
        OCR --> PARSE[Parse JSON]
        PARSE --> IF2{Confident?}
        IF2 -->|No| MSG2[Ask Clarify]
    end
    
    subgraph DATABASE
        IF2 -->|Yes| SEARCH_DB[Search CMMS]
        SEARCH_DB --> IF3{Exists?}
        IF3 -->|Yes| UPDATE[Update]
        IF3 -->|No| CREATE[Create]
    end
    
    subgraph MANUAL_SEARCH
        UPDATE --> QUICK[Quick Search]
        CREATE --> QUICK
        QUICK --> IF4{Found?}
        IF4 -->|Yes| SEND1[Send PDF]
        IF4 -->|No| DEEP[Deep Search]
        DEEP --> IF5{Found?}
        IF5 -->|Yes| SEND2[Send Result]
        IF5 -->|No| SEND3[Not Found]
    end
```

## Node Summary Table

| # | Node Name | Type | Purpose |
|---|-----------|------|---------|
| 1 | Telegram Photo Received | Trigger | Listens for incoming messages |
| 2 | Has Photo? | IF | Routes photo vs text messages |
| 3 | Request Photo | Telegram Send | Asks user to send photo |
| 4 | Get Telegram File | Telegram | Gets file_path from file_id |
| 5 | Download Photo | HTTP Request | Downloads actual image bytes |
| 6 | Gemini Vision OCR | HTTP Request | Sends to Gemini for extraction |
| 7 | Parse OCR Response | Code | Extracts manufacturer/model/serial |
| 8 | Confidence >= 70%? | IF | Routes based on OCR confidence |
| 9 | Ask for Clarification | Telegram Send | Requests clearer photo |
| 10 | Search Atlas CMMS | HTTP Request | Checks if asset exists |
| 11 | Asset Exists? | IF | Routes create vs update |
| 12 | Create Asset | HTTP Request | POST new asset to CMMS |
| 13 | Update Asset | HTTP Request | PATCH existing asset |
| 14 | Quick Manual Search | HTTP Request | Tavily basic search |
| 15 | PDF Found? | IF | Checks if PDF in results |
| 16 | Send PDF Link | Telegram Send | Returns manual to user |
| 17 | Deep Search | HTTP Request | Tavily advanced search |
| 18 | Deep Search Found? | IF | Checks deep search results |
| 19 | Send Deep Result | Telegram Send | Returns deep search result |
| 20 | Send Not Found | Telegram Send | Informs user no manual found |

## Data Flow

```
User sends photo
       │
       ▼
┌──────────────┐
│ Telegram API │ ──► file_id
└──────────────┘
       │
       ▼
┌──────────────┐
│ Download     │ ──► binary image data
└──────────────┘
       │
       ▼
┌──────────────┐     ┌─────────────────────────────┐
│ Gemini OCR   │ ──► │ {                           │
└──────────────┘     │   manufacturer: "Siemens",  │
                     │   model: "6SE6440",         │
                     │   serial: "XVB123456",      │
                     │   confidence: 85            │
                     │ }                           │
                     └─────────────────────────────┘
                              │
              ┌───────────────┴───────────────┐
              ▼                               ▼
       ┌────────────┐                  ┌────────────┐
       │ Atlas CMMS │                  │ Tavily     │
       │ Asset DB   │                  │ Search     │
       └────────────┘                  └────────────┘
              │                               │
              ▼                               ▼
       Asset ID stored              PDF URL found
              │                               │
              └───────────────┬───────────────┘
                              ▼
                     ┌────────────────┐
                     │ Telegram Reply │
                     │ with PDF link  │
                     └────────────────┘
```

## Estimated Latency

| Step | Time |
|------|------|
| Telegram round-trip | ~100ms |
| File download | ~200ms |
| Gemini OCR | 1-2 sec |
| CMMS lookup | ~100ms |
| Tavily quick search | ~500ms |
| Tavily deep search | 1-2 sec |
| **Total (happy path)** | **~3 sec** |
| **Total (with deep search)** | **~5 sec** |
