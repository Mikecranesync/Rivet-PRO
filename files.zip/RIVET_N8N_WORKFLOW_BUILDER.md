# RIVET Pro n8n Workflow Builder

## YOUR MISSION

Generate two outputs:
1. A **Mermaid flowchart** showing the complete workflow visually
2. An **importable n8n workflow JSON** file that can be directly imported into n8n

## THE WORKFLOW: Photo → CMMS → Manual Search

### User Story
A field technician sends a photo of equipment (nameplate, panel, error screen) to Telegram. The system:
1. Extracts manufacturer, model, serial number via OCR
2. Creates/updates asset in Atlas CMMS
3. Searches for the equipment manual (PDF)
4. Returns the manual link immediately if found
5. Falls back to deeper search if not found
6. Always replies to user within reasonable time

---

## OUTPUT 1: Create Mermaid Flowchart

Create a file called `rivet_workflow_diagram.md` with this structure:

```markdown
# RIVET Pro Workflow Architecture

## Main Flow

​```mermaid
flowchart TD
    subgraph TELEGRAM["📱 Telegram Input"]
        A[Photo Received] --> B{Has Photo?}
        B -->|No| A1[Request Photo]
        B -->|Yes| C[Extract File]
    end

    subgraph OCR["🔍 OCR Processing"]
        C --> D[Call Gemini Vision API]
        D --> E[Parse Response]
        E --> F{Extraction Confident?}
        F -->|< 70%| G[Ask User to Clarify]
        F -->|>= 70%| H[Structured Data]
    end

    subgraph CMMS["📋 Atlas CMMS"]
        H --> I[Search Existing Assets]
        I --> J{Asset Exists?}
        J -->|Yes| K[Update Asset Record]
        J -->|No| L[Create New Asset]
        K --> M[Asset ID]
        L --> M
    end

    subgraph SEARCH["🔎 Manual Search"]
        M --> N[Quick Search - Tavily/SerpAPI]
        N --> O{PDF Found?}
        O -->|Yes| P[Extract PDF URL]
        O -->|No| Q[Queue Deep Search]
        Q --> R[Web Crawl Manufacturer Site]
        R --> S{Found After Crawl?}
        S -->|Yes| P
        S -->|No| T[No Manual Available]
    end

    subgraph RESPONSE["💬 User Response"]
        P --> U[Send PDF Link to User]
        T --> V[Send Not Found + Alternatives]
        G --> W[Send Clarification Request]
        U --> X[Log Interaction]
        V --> X
        W --> X
    end

    style TELEGRAM fill:#E3F2FD
    style OCR fill:#FFF3E0
    style CMMS fill:#E8F5E9
    style SEARCH fill:#FCE4EC
    style RESPONSE fill:#F3E5F5
​```

## Node Details

| Node | n8n Node Type | Configuration |
|------|---------------|---------------|
| Photo Received | Telegram Trigger | Trigger on: message, Filter: has photo |
| Call Gemini Vision API | HTTP Request | POST to Gemini API with base64 image |
| Parse Response | Code | JavaScript to extract manufacturer/model/serial |
| Search Existing Assets | HTTP Request | GET to Atlas CMMS API |
| Quick Search | HTTP Request | POST to Tavily/SerpAPI |
| Web Crawl | HTTP Request | Scrape manufacturer support pages |
| Send PDF Link | Telegram | Send message with inline keyboard |
```

---

## OUTPUT 2: Create Importable n8n Workflow JSON

Create a file called `rivet_workflow.json` with this structure.

**CRITICAL n8n JSON RULES:**
- Every node needs unique `id` (use format: `uuid-v4` style or simple like `node_1`)
- Every node needs `position` with `x` and `y` coordinates (space them ~250px apart)
- Connections use `source` and `target` node IDs
- Credentials are referenced by name, user configures after import

```json
{
  "name": "RIVET Pro - Photo to Manual",
  "nodes": [
    {
      "id": "telegram_trigger",
      "name": "Telegram Photo Received",
      "type": "n8n-nodes-base.telegramTrigger",
      "typeVersion": 1.1,
      "position": [0, 0],
      "parameters": {
        "updates": ["message"],
        "additionalFields": {}
      },
      "credentials": {
        "telegramApi": {
          "id": "CONFIGURE_AFTER_IMPORT",
          "name": "Telegram Bot"
        }
      }
    },
    {
      "id": "check_photo",
      "name": "Has Photo?",
      "type": "n8n-nodes-base.if",
      "typeVersion": 2,
      "position": [250, 0],
      "parameters": {
        "conditions": {
          "options": {
            "version": 2,
            "combinator": "and"
          },
          "conditions": [
            {
              "id": "photo_check",
              "leftValue": "={{ $json.message.photo }}",
              "rightValue": "",
              "operator": {
                "type": "exists"
              }
            }
          ]
        }
      }
    },
    {
      "id": "get_file",
      "name": "Get Telegram File",
      "type": "n8n-nodes-base.telegram",
      "typeVersion": 1.2,
      "position": [500, -100],
      "parameters": {
        "operation": "getFile",
        "fileId": "={{ $json.message.photo.slice(-1)[0].file_id }}"
      },
      "credentials": {
        "telegramApi": {
          "id": "CONFIGURE_AFTER_IMPORT",
          "name": "Telegram Bot"
        }
      }
    },
    {
      "id": "download_file",
      "name": "Download Photo",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4.2,
      "position": [750, -100],
      "parameters": {
        "url": "=https://api.telegram.org/file/bot{{ $credentials.telegramApi.accessToken }}/{{ $json.result.file_path }}",
        "options": {
          "response": {
            "response": {
              "responseFormat": "file"
            }
          }
        }
      }
    },
    {
      "id": "ocr_gemini",
      "name": "Gemini Vision OCR",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4.2,
      "position": [1000, -100],
      "parameters": {
        "method": "POST",
        "url": "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent",
        "authentication": "genericCredentialType",
        "genericAuthType": "httpQueryAuth",
        "sendBody": true,
        "specifyBody": "json",
        "jsonBody": "={\n  \"contents\": [{\n    \"parts\": [\n      {\"text\": \"Extract from this equipment photo: manufacturer, model number, serial number, any error codes or fault displays. Return as JSON with keys: manufacturer, model, serial, errors, confidence (0-100).\"},\n      {\"inline_data\": {\"mime_type\": \"image/jpeg\", \"data\": \"{{ $binary.data.toString('base64') }}\"}}\n    ]\n  }]\n}",
        "options": {
          "queryParameters": {
            "parameters": [
              {
                "name": "key",
                "value": "={{ $credentials.googleApi.apiKey }}"
              }
            ]
          }
        }
      }
    },
    {
      "id": "parse_ocr",
      "name": "Parse OCR Response",
      "type": "n8n-nodes-base.code",
      "typeVersion": 2,
      "position": [1250, -100],
      "parameters": {
        "mode": "runOnceForEachItem",
        "jsCode": "// Parse Gemini response and extract structured data\nconst response = $input.item.json;\nconst text = response.candidates?.[0]?.content?.parts?.[0]?.text || '';\n\n// Try to parse JSON from response\nlet extracted = {};\ntry {\n  // Find JSON in response\n  const jsonMatch = text.match(/\\{[\\s\\S]*\\}/);\n  if (jsonMatch) {\n    extracted = JSON.parse(jsonMatch[0]);\n  }\n} catch (e) {\n  // Fallback: extract with regex\n  extracted = {\n    manufacturer: text.match(/manufacturer[:\\s]+([\\w\\s]+)/i)?.[1]?.trim() || 'Unknown',\n    model: text.match(/model[:\\s]+([\\w\\-]+)/i)?.[1]?.trim() || 'Unknown',\n    serial: text.match(/serial[:\\s]+([\\w\\-]+)/i)?.[1]?.trim() || 'Unknown',\n    errors: text.match(/error[:\\s]+([\\w\\d]+)/i)?.[1]?.trim() || null,\n    confidence: 50\n  };\n}\n\nreturn {\n  json: {\n    ...extracted,\n    raw_text: text,\n    chat_id: $('Telegram Photo Received').item.json.message.chat.id\n  }\n};"
      }
    },
    {
      "id": "confidence_check",
      "name": "Confidence >= 70%?",
      "type": "n8n-nodes-base.if",
      "typeVersion": 2,
      "position": [1500, -100],
      "parameters": {
        "conditions": {
          "options": {
            "version": 2,
            "combinator": "and"
          },
          "conditions": [
            {
              "id": "conf_check",
              "leftValue": "={{ $json.confidence }}",
              "rightValue": 70,
              "operator": {
                "type": "number",
                "operation": "gte"
              }
            }
          ]
        }
      }
    },
    {
      "id": "cmms_search",
      "name": "Search Atlas CMMS",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4.2,
      "position": [1750, -200],
      "parameters": {
        "method": "GET",
        "url": "={{ $vars.ATLAS_CMMS_URL }}/api/assets",
        "authentication": "genericCredentialType",
        "genericAuthType": "httpHeaderAuth",
        "sendQuery": true,
        "queryParameters": {
          "parameters": [
            {
              "name": "manufacturer",
              "value": "={{ $json.manufacturer }}"
            },
            {
              "name": "model",
              "value": "={{ $json.model }}"
            }
          ]
        }
      }
    },
    {
      "id": "asset_exists",
      "name": "Asset Exists?",
      "type": "n8n-nodes-base.if",
      "typeVersion": 2,
      "position": [2000, -200],
      "parameters": {
        "conditions": {
          "options": {
            "version": 2,
            "combinator": "and"
          },
          "conditions": [
            {
              "id": "asset_check",
              "leftValue": "={{ $json.data.length }}",
              "rightValue": 0,
              "operator": {
                "type": "number",
                "operation": "gt"
              }
            }
          ]
        }
      }
    },
    {
      "id": "create_asset",
      "name": "Create Asset",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4.2,
      "position": [2250, -100],
      "parameters": {
        "method": "POST",
        "url": "={{ $vars.ATLAS_CMMS_URL }}/api/assets",
        "authentication": "genericCredentialType",
        "genericAuthType": "httpHeaderAuth",
        "sendBody": true,
        "specifyBody": "json",
        "jsonBody": "={\n  \"manufacturer\": \"{{ $('Parse OCR Response').item.json.manufacturer }}\",\n  \"model\": \"{{ $('Parse OCR Response').item.json.model }}\",\n  \"serial\": \"{{ $('Parse OCR Response').item.json.serial }}\",\n  \"created_via\": \"telegram_bot\"\n}"
      }
    },
    {
      "id": "update_asset",
      "name": "Update Asset",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4.2,
      "position": [2250, -300],
      "parameters": {
        "method": "PATCH",
        "url": "={{ $vars.ATLAS_CMMS_URL }}/api/assets/{{ $json.data[0].id }}",
        "authentication": "genericCredentialType",
        "genericAuthType": "httpHeaderAuth",
        "sendBody": true,
        "specifyBody": "json",
        "jsonBody": "={\n  \"last_seen\": \"{{ new Date().toISOString() }}\",\n  \"serial\": \"{{ $('Parse OCR Response').item.json.serial }}\"\n}"
      }
    },
    {
      "id": "quick_search",
      "name": "Quick Manual Search",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4.2,
      "position": [2500, -200],
      "parameters": {
        "method": "POST",
        "url": "https://api.tavily.com/search",
        "authentication": "genericCredentialType",
        "genericAuthType": "httpHeaderAuth",
        "sendBody": true,
        "specifyBody": "json",
        "jsonBody": "={\n  \"query\": \"{{ $('Parse OCR Response').item.json.manufacturer }} {{ $('Parse OCR Response').item.json.model }} user manual PDF filetype:pdf\",\n  \"search_depth\": \"basic\",\n  \"include_answer\": false,\n  \"max_results\": 5\n}"
      }
    },
    {
      "id": "pdf_found",
      "name": "PDF Found?",
      "type": "n8n-nodes-base.if",
      "typeVersion": 2,
      "position": [2750, -200],
      "parameters": {
        "conditions": {
          "options": {
            "version": 2,
            "combinator": "or"
          },
          "conditions": [
            {
              "id": "pdf_check",
              "leftValue": "={{ $json.results.filter(r => r.url.includes('.pdf')).length }}",
              "rightValue": 0,
              "operator": {
                "type": "number",
                "operation": "gt"
              }
            }
          ]
        }
      }
    },
    {
      "id": "send_pdf_link",
      "name": "Send PDF Link",
      "type": "n8n-nodes-base.telegram",
      "typeVersion": 1.2,
      "position": [3000, -300],
      "parameters": {
        "operation": "sendMessage",
        "chatId": "={{ $('Parse OCR Response').item.json.chat_id }}",
        "text": "=📋 **Manual Found!**\n\n**Equipment:** {{ $('Parse OCR Response').item.json.manufacturer }} {{ $('Parse OCR Response').item.json.model }}\n\n📥 [Download Manual]({{ $json.results.filter(r => r.url.includes('.pdf'))[0].url }})\n\n_Asset saved to CMMS_",
        "additionalFields": {
          "parse_mode": "Markdown"
        }
      },
      "credentials": {
        "telegramApi": {
          "id": "CONFIGURE_AFTER_IMPORT",
          "name": "Telegram Bot"
        }
      }
    },
    {
      "id": "deep_search",
      "name": "Deep Search - Manufacturer Site",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4.2,
      "position": [3000, -100],
      "parameters": {
        "method": "POST",
        "url": "https://api.tavily.com/search",
        "authentication": "genericCredentialType",
        "genericAuthType": "httpHeaderAuth",
        "sendBody": true,
        "specifyBody": "json",
        "jsonBody": "={\n  \"query\": \"site:{{ $('Parse OCR Response').item.json.manufacturer.toLowerCase().replace(/\\s/g, '') }}.com {{ $('Parse OCR Response').item.json.model }} manual PDF download\",\n  \"search_depth\": \"advanced\",\n  \"include_answer\": false,\n  \"max_results\": 10\n}"
      }
    },
    {
      "id": "deep_pdf_found",
      "name": "Deep Search Found PDF?",
      "type": "n8n-nodes-base.if",
      "typeVersion": 2,
      "position": [3250, -100],
      "parameters": {
        "conditions": {
          "options": {
            "version": 2,
            "combinator": "or"
          },
          "conditions": [
            {
              "id": "deep_pdf_check",
              "leftValue": "={{ $json.results.filter(r => r.url.includes('.pdf') || r.url.includes('manual') || r.url.includes('download')).length }}",
              "rightValue": 0,
              "operator": {
                "type": "number",
                "operation": "gt"
              }
            }
          ]
        }
      }
    },
    {
      "id": "send_deep_result",
      "name": "Send Deep Search Result",
      "type": "n8n-nodes-base.telegram",
      "typeVersion": 1.2,
      "position": [3500, -200],
      "parameters": {
        "operation": "sendMessage",
        "chatId": "={{ $('Parse OCR Response').item.json.chat_id }}",
        "text": "=📋 **Manual Found (Deep Search)**\n\n**Equipment:** {{ $('Parse OCR Response').item.json.manufacturer }} {{ $('Parse OCR Response').item.json.model }}\n\n📥 [Download Manual]({{ $json.results[0].url }})\n\n_Asset saved to CMMS_",
        "additionalFields": {
          "parse_mode": "Markdown"
        }
      },
      "credentials": {
        "telegramApi": {
          "id": "CONFIGURE_AFTER_IMPORT",
          "name": "Telegram Bot"
        }
      }
    },
    {
      "id": "send_not_found",
      "name": "Send Not Found",
      "type": "n8n-nodes-base.telegram",
      "typeVersion": 1.2,
      "position": [3500, 0],
      "parameters": {
        "operation": "sendMessage",
        "chatId": "={{ $('Parse OCR Response').item.json.chat_id }}",
        "text": "=⚠️ **Manual Not Found**\n\n**Equipment:** {{ $('Parse OCR Response').item.json.manufacturer }} {{ $('Parse OCR Response').item.json.model }}\n\nI couldn't find a PDF manual automatically. Try:\n• Check manufacturer's support site directly\n• Search for \"{{ $('Parse OCR Response').item.json.model }} manual PDF\"\n• Contact manufacturer support\n\n_Asset saved to CMMS_",
        "additionalFields": {
          "parse_mode": "Markdown"
        }
      },
      "credentials": {
        "telegramApi": {
          "id": "CONFIGURE_AFTER_IMPORT",
          "name": "Telegram Bot"
        }
      }
    },
    {
      "id": "ask_clarification",
      "name": "Ask for Clarification",
      "type": "n8n-nodes-base.telegram",
      "typeVersion": 1.2,
      "position": [1750, 0],
      "parameters": {
        "operation": "sendMessage",
        "chatId": "={{ $json.chat_id }}",
        "text": "=🔍 I couldn't read the equipment info clearly.\n\nI found:\n• Manufacturer: {{ $json.manufacturer || 'unclear' }}\n• Model: {{ $json.model || 'unclear' }}\n\nCould you:\n1. Take a clearer photo of the nameplate\n2. Or type the manufacturer and model number",
        "additionalFields": {
          "parse_mode": "Markdown"
        }
      },
      "credentials": {
        "telegramApi": {
          "id": "CONFIGURE_AFTER_IMPORT",
          "name": "Telegram Bot"
        }
      }
    },
    {
      "id": "no_photo_response",
      "name": "Request Photo",
      "type": "n8n-nodes-base.telegram",
      "typeVersion": 1.2,
      "position": [500, 100],
      "parameters": {
        "operation": "sendMessage",
        "chatId": "={{ $json.message.chat.id }}",
        "text": "📸 Please send a photo of the equipment nameplate, panel, or error display.\n\nI'll:\n• Extract the manufacturer and model\n• Find the manual for you\n• Save it to your CMMS",
        "additionalFields": {}
      },
      "credentials": {
        "telegramApi": {
          "id": "CONFIGURE_AFTER_IMPORT",
          "name": "Telegram Bot"
        }
      }
    }
  ],
  "connections": {
    "Telegram Photo Received": {
      "main": [
        [
          {
            "node": "Has Photo?",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Has Photo?": {
      "main": [
        [
          {
            "node": "Get Telegram File",
            "type": "main",
            "index": 0
          }
        ],
        [
          {
            "node": "Request Photo",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Get Telegram File": {
      "main": [
        [
          {
            "node": "Download Photo",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Download Photo": {
      "main": [
        [
          {
            "node": "Gemini Vision OCR",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Gemini Vision OCR": {
      "main": [
        [
          {
            "node": "Parse OCR Response",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Parse OCR Response": {
      "main": [
        [
          {
            "node": "Confidence >= 70%?",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Confidence >= 70%?": {
      "main": [
        [
          {
            "node": "Search Atlas CMMS",
            "type": "main",
            "index": 0
          }
        ],
        [
          {
            "node": "Ask for Clarification",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Search Atlas CMMS": {
      "main": [
        [
          {
            "node": "Asset Exists?",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Asset Exists?": {
      "main": [
        [
          {
            "node": "Update Asset",
            "type": "main",
            "index": 0
          }
        ],
        [
          {
            "node": "Create Asset",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Update Asset": {
      "main": [
        [
          {
            "node": "Quick Manual Search",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Create Asset": {
      "main": [
        [
          {
            "node": "Quick Manual Search",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Quick Manual Search": {
      "main": [
        [
          {
            "node": "PDF Found?",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "PDF Found?": {
      "main": [
        [
          {
            "node": "Send PDF Link",
            "type": "main",
            "index": 0
          }
        ],
        [
          {
            "node": "Deep Search - Manufacturer Site",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Deep Search - Manufacturer Site": {
      "main": [
        [
          {
            "node": "Deep Search Found PDF?",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Deep Search Found PDF?": {
      "main": [
        [
          {
            "node": "Send Deep Search Result",
            "type": "main",
            "index": 0
          }
        ],
        [
          {
            "node": "Send Not Found",
            "type": "main",
            "index": 0
          }
        ]
      ]
    }
  },
  "settings": {
    "executionOrder": "v1"
  },
  "staticData": null,
  "tags": [],
  "triggerCount": 1,
  "variables": [
    {
      "key": "ATLAS_CMMS_URL",
      "value": "https://your-atlas-instance.com"
    }
  ]
}
```

---

## OUTPUT 3: Node Configuration Reference

Create a file called `rivet_node_configs.md` with detailed setup instructions:

```markdown
# RIVET Pro - Node Configuration Guide

## After Import Checklist

### 1. Credentials to Configure

| Credential Name | Type | Where to Get |
|-----------------|------|--------------|
| Telegram Bot | Telegram API | @BotFather on Telegram |
| Google API (Gemini) | HTTP Query Auth | Google AI Studio |
| Tavily API | HTTP Header Auth | tavily.com |
| Atlas CMMS | HTTP Header Auth | Your Atlas instance |

### 2. Variables to Set

Go to **Settings > Variables** in n8n:

| Variable | Value |
|----------|-------|
| ATLAS_CMMS_URL | `https://your-atlas-cmms.com` |

### 3. Node-by-Node Setup

#### Telegram Trigger
- Credential: Select your Telegram Bot credential
- Updates: `message` only
- No filters needed (we check for photo in next node)

#### Gemini Vision OCR
- The prompt is embedded in the JSON body
- Make sure your Google API key is in credentials
- Model: `gemini-1.5-flash` (fastest, cheapest)

#### Parse OCR Response (Code Node)
- This extracts structured JSON from Gemini's response
- Handles both clean JSON and messy text responses
- Passes `chat_id` forward for replies

#### Atlas CMMS Nodes
- Replace URL with your actual Atlas API endpoint
- Authentication: Usually Bearer token in header
- Adjust field names to match your CMMS schema

#### Tavily Search
- API key in header: `Authorization: Bearer YOUR_KEY`
- `search_depth: basic` for quick (faster)
- `search_depth: advanced` for deep (slower but thorough)

### 4. Testing Sequence

1. **Test Telegram Trigger**: Send any message, verify it fires
2. **Test with text only**: Should reply "Please send a photo"
3. **Test with photo**: Send equipment nameplate photo
4. **Verify OCR output**: Check Parse node output in execution
5. **Check CMMS integration**: Verify asset created/updated
6. **Test search**: Confirm Tavily returns results
```

---

## EXECUTION INSTRUCTIONS

Run these commands after generating the files:

```bash
# Create output directory
mkdir -p /home/claude/rivet-n8n-workflow

# Files to create:
# 1. /home/claude/rivet-n8n-workflow/rivet_workflow_diagram.md (Mermaid chart)
# 2. /home/claude/rivet-n8n-workflow/rivet_workflow.json (importable n8n workflow)
# 3. /home/claude/rivet-n8n-workflow/rivet_node_configs.md (setup guide)

# After generation, user imports rivet_workflow.json into n8n via:
# n8n UI > Workflows > Import from File
```

---

## SUCCESS CRITERIA

- [ ] Mermaid diagram renders correctly (paste into mermaid.live to verify)
- [ ] JSON is valid (run through `jq .` to verify)
- [ ] All node IDs are unique
- [ ] All connections reference valid node names
- [ ] Credentials marked as "CONFIGURE_AFTER_IMPORT"
- [ ] Variables section includes ATLAS_CMMS_URL
