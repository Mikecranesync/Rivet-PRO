# RIVET Pro n8n Workflow - Setup Guide

## Quick Start

1. Import `rivet_workflow.json` into n8n (Workflows → Import from File)
2. Configure credentials (see below)
3. Set the ATLAS_CMMS_URL variable
4. Activate the workflow
5. Send a photo to your Telegram bot

---

## Credentials to Configure

After import, you'll see red warning icons on nodes. Configure these credentials:

### 1. Telegram Bot API

**Create credential:** Settings → Credentials → Add Credential → Telegram

| Field | Value |
|-------|-------|
| Access Token | Get from @BotFather on Telegram |

**Used by nodes:** Telegram Photo Received, Get Telegram File, Request Photo, Ask for Clarification, Send PDF Link, Send Deep Result, Send Not Found

---

### 2. Google Gemini API

**Create credential:** Settings → Credentials → Add Credential → Google AI (or HTTP Header Auth)

| Field | Value |
|-------|-------|
| API Key | Get from https://aistudio.google.com/apikey |

**Used by node:** Gemini Vision OCR

**Note:** The API key is passed in the URL query parameter. If n8n's native Google AI credential doesn't work, use HTTP Header Auth with:
- Header Name: `x-goog-api-key`
- Header Value: `your-api-key`

---

### 3. Tavily API

**Create credential:** Settings → Credentials → Add Credential → HTTP Header Auth

| Field | Value |
|-------|-------|
| Name | `Authorization` |
| Value | `Bearer tvly-xxxxxxxxxxxxx` |

Get your API key from: https://tavily.com

**Used by nodes:** Quick Manual Search, Deep Search

---

### 4. Atlas CMMS API

**Create credential:** Settings → Credentials → Add Credential → HTTP Header Auth

| Field | Value |
|-------|-------|
| Name | `Authorization` |
| Value | `Bearer your-cmms-token` |

**Used by nodes:** Search Atlas CMMS, Update Asset, Create Asset

---

## Variables to Set

Go to **Settings → Variables** and add:

| Variable | Example Value |
|----------|---------------|
| `ATLAS_CMMS_URL` | `https://your-atlas-instance.com` |

---

## Node-by-Node Verification

### Telegram Trigger
- ✅ Credential assigned
- ✅ Updates: `message` selected
- Test: Send any message to bot, check execution history

### Has Photo? (IF node)
- Checks: `{{ $json.message.photo }}` exists
- True path → Get Telegram File
- False path → Request Photo

### Get Telegram File
- Gets the file_id from the largest photo size
- Expression: `{{ $json.message.photo.slice(-1)[0].file_id }}`

### Download Photo
- Downloads via Telegram Bot API file endpoint
- Returns binary data for Gemini

### Gemini Vision OCR
- Model: `gemini-1.5-flash` (fast, cheap)
- Prompt requests structured JSON output
- Extracts: manufacturer, model, serial, errors, confidence

### Parse OCR Response (Code node)
- Extracts JSON from Gemini's text response
- Falls back to regex if JSON parsing fails
- Preserves `chat_id` for reply routing

### Confidence Check
- Threshold: 70%
- Low confidence → Ask for clarification
- High confidence → Continue to CMMS

### CMMS Search
- Searches by manufacturer + model
- Adjust query params to match your CMMS API

### Asset Exists?
- Checks if search returned results
- True → Update existing
- False → Create new

### Manual Search
- Quick search: Tavily basic (500ms)
- Deep search: Tavily advanced with site: filter (2s)

### Response Nodes
- All use Markdown formatting
- Include equipment info from OCR
- Link to PDF when found

---

## Testing Checklist

| Step | Test | Expected Result |
|------|------|-----------------|
| 1 | Send text message | "Please send a photo" response |
| 2 | Send blurry photo | "Couldn't read clearly" response |
| 3 | Send clear nameplate | Manufacturer/model extracted |
| 4 | Check CMMS | Asset created/updated |
| 5 | Check search | PDF link returned (or not found) |

---

## Troubleshooting

### "Credential not found"
- Reassign the credential in the node settings
- Make sure credential name matches exactly

### Gemini returns empty
- Check API key is valid
- Verify image is being sent as base64
- Check execution data for error message

### CMMS returns 401
- Check Authorization header format
- Verify token is valid
- Check ATLAS_CMMS_URL variable is set

### No PDF found for known equipment
- Try different search terms in Tavily node
- Check if manufacturer blocks crawlers
- Add fallback to Google Custom Search

---

## Next Steps After This Works

1. **Add WhatsApp** - Same flow, different trigger node
2. **Add voice messages** - Whisper transcription node before OCR
3. **Add PLC panel photos** - Route to specialized OCR prompts
4. **Add knowledge base** - Vector search before web search
5. **Add user tiers** - Rate limiting node after trigger
